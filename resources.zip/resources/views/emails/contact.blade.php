<p><strong>نام:</strong> {{ $name }}</p>
<p><strong>ایمیل:</strong> {{ $email }}</p>
<p><strong>موضوع:</strong> {{ $title }}</p>
<p><strong>پیام:</strong></p>
<p>{{ $description }}</p>